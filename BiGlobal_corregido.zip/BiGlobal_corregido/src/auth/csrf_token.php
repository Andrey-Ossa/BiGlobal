<?php

require_once __DIR__ . "/../auth/csrf.php";
require_once __DIR__ . "/../../app/Controllers/AuthController.php";

(new AuthController())->csrfToken();